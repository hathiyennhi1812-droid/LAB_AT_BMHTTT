/*
 * Decompiled with CFR 0.152.
 */
package week_01;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

public final class FileTextIO {
    private FileTextIO() {
    }

    public static String openText(JFrame parent, JTextArea target) {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Text file (*.txt)", "txt"));
        if (chooser.showOpenDialog(parent) != 0) {
            return null;
        }
        File file = chooser.getSelectedFile();
        try {
            target.setText(Files.readString(file.toPath(), StandardCharsets.UTF_8).trim());
            return file.getAbsolutePath();
        }
        catch (Exception ex) {
            JOptionPane.showMessageDialog(parent, "Kh\u00f4ng \u0111\u1ecdc \u0111\u01b0\u1ee3c t\u1ec7p: " + ex.getMessage(), "L\u1ed7i m\u1edf t\u1ec7p", 0);
            return null;
        }
    }

    public static String saveText(JFrame parent, JTextArea source, String defaultName) {
        if (source.getText().isBlank()) {
            JOptionPane.showMessageDialog(parent, "Ch\u01b0a c\u00f3 n\u1ed9i dung \u0111\u1ec3 l\u01b0u.");
            return null;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(defaultName));
        if (chooser.showSaveDialog(parent) != 0) {
            return null;
        }
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".txt")) {
            file = new File(file.getParentFile(), file.getName() + ".txt");
        }
        try {
            Files.writeString(file.toPath(), (CharSequence)source.getText(), StandardCharsets.UTF_8, new OpenOption[0]);
            return file.getAbsolutePath();
        }
        catch (Exception ex) {
            JOptionPane.showMessageDialog(parent, "Kh\u00f4ng l\u01b0u \u0111\u01b0\u1ee3c t\u1ec7p: " + ex.getMessage(), "L\u1ed7i l\u01b0u t\u1ec7p", 0);
            return null;
        }
    }

    public static String openString(JFrame parent) {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Text file (*.txt)", "txt"));
        if (chooser.showOpenDialog(parent) != 0) {
            return null;
        }
        try {
            return Files.readString(chooser.getSelectedFile().toPath(), StandardCharsets.UTF_8);
        }
        catch (Exception ex) {
            JOptionPane.showMessageDialog(parent, "Kh\u00f4ng \u0111\u1ecdc \u0111\u01b0\u1ee3c t\u1ec7p: " + ex.getMessage(), "L\u1ed7i m\u1edf t\u1ec7p", 0);
            return null;
        }
    }

    public static String saveString(JFrame parent, String content, String defaultName) {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(defaultName));
        if (chooser.showSaveDialog(parent) != 0) {
            return null;
        }
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".txt")) {
            file = new File(file.getParentFile(), file.getName() + ".txt");
        }
        try {
            Files.writeString(file.toPath(), (CharSequence)content, StandardCharsets.UTF_8, new OpenOption[0]);
            return file.getAbsolutePath();
        }
        catch (Exception ex) {
            JOptionPane.showMessageDialog(parent, "Kh\u00f4ng l\u01b0u \u0111\u01b0\u1ee3c t\u1ec7p: " + ex.getMessage(), "L\u1ed7i l\u01b0u t\u1ec7p", 0);
            return null;
        }
    }
}

