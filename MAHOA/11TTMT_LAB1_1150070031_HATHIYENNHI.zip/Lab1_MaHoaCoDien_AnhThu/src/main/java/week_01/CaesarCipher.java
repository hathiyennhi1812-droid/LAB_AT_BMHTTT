/*
 * Decompiled with CFR 0.152.
 */
package week_01;

public final class CaesarCipher {
    private CaesarCipher() {
    }

    public static String encrypt(String text, int key) {
        return CaesarCipher.transform(text, key);
    }

    public static String decrypt(String text, int key) {
        return CaesarCipher.transform(text, -key);
    }

    private static String transform(String text, int key) {
        StringBuilder result = new StringBuilder();
        int shift = Math.floorMod(key, 26);
        for (char c : text.toCharArray()) {
            int base;
            if (c >= 'A' && c <= 'Z') {
                base = 65;
            } else if (c >= 'a' && c <= 'z') {
                base = 97;
            } else {
                result.append(c);
                continue;
            }
            int original = c - base;
            int encoded = Math.floorMod(original + shift, 26);
            result.append((char)(base + encoded));
        }
        return result.toString();
    }
}

