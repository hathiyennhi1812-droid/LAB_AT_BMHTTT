/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package week_01;

/**
 *
 * @author HP
 */
public class Lab1_MaHoaCoDien_AnhThu {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
