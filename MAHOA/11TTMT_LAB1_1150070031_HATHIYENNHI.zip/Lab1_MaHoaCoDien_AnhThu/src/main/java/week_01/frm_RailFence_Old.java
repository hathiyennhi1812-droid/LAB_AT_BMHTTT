/*
 * Decompiled with CFR 0.152.
 */
package week_01;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import week_01.CaesarCipher;

public class frm_RailFence_Old
extends JFrame {
    private JButton btnClear;
    private JButton btnDecrypt;
    private JButton btnEncrypt;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JScrollPane jScrollPane1;
    private JScrollPane jScrollPane2;
    private JTextField txtKey;
    private JTextArea txtPlain;
    private JTextArea txtResult;

    public frm_RailFence_Old() {
        this.initComponents();
    }

    private void initComponents() {
        this.jLabel1 = new JLabel();
        this.jLabel2 = new JLabel();
        this.jScrollPane1 = new JScrollPane();
        this.txtPlain = new JTextArea();
        this.jLabel3 = new JLabel();
        this.txtKey = new JTextField();
        this.btnEncrypt = new JButton();
        this.btnDecrypt = new JButton();
        this.btnClear = new JButton();
        this.jLabel4 = new JLabel();
        this.jScrollPane2 = new JScrollPane();
        this.txtResult = new JTextArea();
        this.setDefaultCloseOperation(3);
        this.setTitle("M\u00c3 H\u00d3A CAESAR");
        this.setPreferredSize(new Dimension(750, 500));
        this.jLabel1.setFont(new Font("Segoe UI", 1, 20));
        this.jLabel1.setHorizontalAlignment(0);
        this.jLabel1.setText("CH\u01af\u01a0NG TR\u00ccNH M\u00c3 H\u00d3A CAESAR");
        this.jLabel2.setText("V\u0103n b\u1ea3n \u0111\u1ea7u v\u00e0o:");
        this.txtPlain.setColumns(20);
        this.txtPlain.setRows(5);
        this.jScrollPane1.setViewportView(this.txtPlain);
        this.jLabel3.setText("Kh\u00f3a d\u1ecbch chuy\u1ec3n (k):");
        this.txtKey.setText("3");
        this.btnEncrypt.setText("M\u00e3  h\u00f3a");
        this.btnEncrypt.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent evt) {
                frm_RailFence_Old.this.btnEncryptActionPerformed(evt);
            }
        });
        this.btnDecrypt.setText("Gi\u1ea3i m\u00e3");
        this.btnDecrypt.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent evt) {
                frm_RailFence_Old.this.btnDecryptActionPerformed(evt);
            }
        });
        this.btnClear.setText("L\u00e0m m\u1edbi");
        this.btnClear.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent evt) {
                frm_RailFence_Old.this.btnClearActionPerformed(evt);
            }
        });
        this.jLabel4.setText("K\u1ebft qu\u1ea3:");
        this.txtResult.setEditable(false);
        this.txtResult.setColumns(20);
        this.txtResult.setRows(5);
        this.jScrollPane2.setViewportView(this.txtResult);
        GroupLayout layout = new GroupLayout(this.getContentPane());
        this.getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel2, -2, 108, -2).addComponent(this.jLabel3, -2, 129, -2).addComponent(this.btnEncrypt).addComponent(this.jLabel4, -2, 73, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.btnDecrypt).addGap(71, 71, 71).addComponent(this.btnClear)).addComponent(this.txtKey, -2, 71, -2).addComponent(this.jLabel1).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.jScrollPane2, GroupLayout.Alignment.LEADING, -1, 321, Short.MAX_VALUE).addComponent(this.jScrollPane1, GroupLayout.Alignment.LEADING))).addContainerGap(-1, Short.MAX_VALUE)));
        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jLabel1, -2, 36, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1, -2, 42, -2).addComponent(this.jLabel2)).addGap(17, 17, 17).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel3).addComponent(this.txtKey, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.btnEncrypt).addComponent(this.btnDecrypt).addComponent(this.btnClear)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel4).addComponent(this.jScrollPane2, -2, 46, -2)).addContainerGap(34, Short.MAX_VALUE)));
        this.pack();
    }

    private void btnEncryptActionPerformed(ActionEvent evt) {
        try {
            String text = this.txtPlain.getText();
            int k = Integer.parseInt(this.txtKey.getText().trim());
            String result = CaesarCipher.encrypt(text, k);
            this.txtResult.setText(result);
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Kh\u00f3a d\u1ecbch chuy\u1ec3n ph\u1ea3i l\u00e0 s\u1ed1 nguy\u00ean!");
        }
    }

    private void btnDecryptActionPerformed(ActionEvent evt) {
        try {
            String text = this.txtPlain.getText();
            int k = Integer.parseInt(this.txtKey.getText().trim());
            String result = CaesarCipher.decrypt(text, k);
            this.txtResult.setText(result);
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Kh\u00f3a d\u1ecbch chuy\u1ec3n ph\u1ea3i l\u00e0 s\u1ed1 nguy\u00ean!");
        }
    }

    private void btnClearActionPerformed(ActionEvent evt) {
        this.txtPlain.setText("");
        this.txtKey.setText("3");
        this.txtResult.setText("");
        this.txtPlain.requestFocus();
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if (!"Nimbus".equals(info.getName())) continue;
                UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
        catch (ClassNotFoundException ex) {
            Logger.getLogger(frm_RailFence_Old.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (InstantiationException ex) {
            Logger.getLogger(frm_RailFence_Old.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (IllegalAccessException ex) {
            Logger.getLogger(frm_RailFence_Old.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(frm_RailFence_Old.class.getName()).log(Level.SEVERE, null, ex);
        }
        EventQueue.invokeLater(new Runnable(){

            @Override
            public void run() {
                new frm_RailFence_Old().setVisible(true);
            }
        });
    }
}

